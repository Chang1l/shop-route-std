import './App.css';
import React, {Component } from 'react';
import Field from './Field';

class App extends Component{
  render(){
    return(
        <div>
          <Field/>
        </div>
    );
  }
}

export default App;
